/**
 * Проверка собранного сайта против ограничений брифа.
 * Запуск: npm run build && npm run start, затем node scripts/check.mjs http://localhost:3000
 *
 * Проверяется то, что легко нарушить незаметно при правке текстов:
 *  1. на русской версии нет темы VPN и обхода блокировок
 *  2. нигде не упоминаются способы оплаты картой и рублями
 *  3. нет превосходной степени без ссылки на методологию
 *  4. партнёрские ссылки собраны верно, метка стоит до якоря
 *  5. у партнёрских ссылок проставлен rel sponsored nofollow
 *  6. счётчик Метрики на месте
 */

const BASE = process.argv[2] || 'http://localhost:3000';

const PAGES = [
  // Английский — основной, в корне
  '/', '/catalog', '/providers', '/vps-for', '/vps-in', '/news', '/deals',
  '/methodology', '/about', '/privacy', '/cookie',
  '/providers/ultahost', '/providers/regru', '/providers/vdsina',
  '/vps-for/1c-bitrix', '/vps-for/n8n', '/vps-in/evropa',
  '/news/nvme-protiv-ssd-kogda-raznica-zametna',
  // Русский — под /ru
  '/ru', '/ru/catalog', '/ru/provajdery', '/ru/vps-dlya', '/ru/vps', '/ru/novosti', '/ru/akcii',
  '/ru/metodologiya', '/ru/o-proekte', '/ru/politika-konfidencialnosti', '/ru/cookie',
  '/ru/provajdery/timeweb', '/ru/provajdery/ultahost', '/ru/provajdery/regru', '/ru/provajdery/vdsina',
  '/ru/vps-dlya/1c-bitrix', '/ru/vps/rossiya',
  '/ru/novosti/timeweb-cloud-vtoroe-mesto-reyting-partnerskih-programm',
  '/ru/novosti/adminvps-desyat-let-i-tridcat-tysyach-klientov',
];

const FORBIDDEN = [
  { re: /\bvpn\b/i, why: 'тема VPN закрыта на русской версии (раздел 3.1 брифа)' },
  { re: /впн/i, why: 'тема VPN закрыта на русской версии' },
  { re: /обход\w* блокиров/i, why: 'обход блокировок закрыт на русской версии' },
  { re: /карт(ой|ы|а) РФ/i, why: 'упоминания оплаты картой РФ убраны по решению владельца' },
  { re: /оплат\w* рублями/i, why: 'ось способов оплаты убрана целиком' },
  { re: /российской картой/i, why: 'ось способов оплаты убрана целиком' },
  { re: /\bлучший хостинг\b/i, why: 'превосходная степень без критерия сравнения' },
  { re: /номер один/i, why: 'превосходная степень без критерия сравнения' },
];

let errors = 0;
let warnings = 0;
const fail = (msg) => { errors += 1; console.log(`  ОШИБКА  ${msg}`); };
const warn = (msg) => { warnings += 1; console.log(`  внимание ${msg}`); };

function strip(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ');
}

console.log(`Проверка сборки на ${BASE}\n`);

const pages = new Map();
for (const path of PAGES) {
  const res = await fetch(BASE + path);
  if (!res.ok) { fail(`${path} отвечает ${res.status}`); continue; }
  pages.set(path, await res.text());
}
console.log(`1. Страницы отвечают: ${pages.size} из ${PAGES.length}`);

// 1-3. запрещённые формулировки в видимом тексте
console.log('\n2. Запрещённые темы и формулировки');
for (const [path, html] of pages) {
  const text = strip(html);
  for (const { re, why } of FORBIDDEN) {
    const hit = text.match(re);
    if (hit) fail(`${path}: «${hit[0]}» — ${why}`);
  }
}
if (errors === 0) console.log('  чисто');

// 4. партнёрские ссылки
console.log('\n3. Партнёрские ссылки и метки');
const ULTA = /https:\/\/ultahost\.com\/\?[^"']*#MakeBiz/;
const ultaPage = pages.get('/providers/ultahost') || '';
if (ULTA.test(ultaPage)) {
  console.log('  UltaHost: метка стоит до якоря, реферальный идентификатор цел');
} else if (/ultahost\.com\/#MakeBiz\?/.test(ultaPage)) {
  fail('UltaHost: метка попала ПОСЛЕ якоря, реферальный идентификатор сломан');
} else {
  warn('UltaHost: ссылку в разметке найти не удалось, проверить вручную');
}

const allHtml = [...pages.values()].join('\n');
const outLinks = [...allHtml.matchAll(/<a[^>]+href="(https?:\/\/[^"]+)"[^>]*>/g)];
const external = outLinks.filter(([, href]) => !href.includes('localhost') && !href.includes('mc.yandex'));
const withSource = external.filter(([, href]) => href.includes('utm_source=servercalc'));
console.log(`  внешних ссылок: ${external.length}, из них с меткой servercalc: ${withSource.length}`);

const badRel = external.filter(([tag, href]) => href.includes('utm_source=') && !/rel="sponsored nofollow noopener"/.test(tag));
if (badRel.length) fail(`${badRel.length} партнёрских ссылок без rel="sponsored nofollow noopener"`);
else console.log('  у всех партнёрских ссылок проставлен rel sponsored nofollow noopener');

const campaigns = new Set(
  external.map(([, href]) => (href.match(/utm_campaign=([^&#]+)/) || [])[1]).filter(Boolean)
);
console.log(`  разрезы utm_campaign: ${[...campaigns].join(', ') || 'нет'}`);

// 5. подтверждённые партнёрки обязаны получать метку.
// VDSina активирована 7 августа (реф-ссылка partner=...), раньше была контролем «без метки».
// Сейчас все провайдеры в базе партнёрские, отдельного непартнёрского контроля нет
const vdsina = pages.get('/providers/vdsina') || '';
if (/vdsina\.ru[^"']*utm_source=servercalc/.test(vdsina)) {
  console.log('  VDSina: партнёрская ссылка с меткой на месте');
} else {
  fail('VDSina: партнёрка подтверждена, а метки на ссылке нет');
}
// и обратная проверка: у подтверждённой партнёрки метка обязана быть
const regru = pages.get('/providers/regru') || '';
if (/reg\.ru[^"']*utm_source=servercalc/.test(regru)) {
  console.log('  Reg.ru: партнёрская ссылка с меткой на месте');
} else {
  fail('Reg.ru: партнёрка подтверждена, а метки на ссылке нет');
}

// 6. счётчик
console.log('\n4. Аналитика и техника');
const home = pages.get('/') || '';
if (home.includes('mc.yandex.ru/metrika/tag.js?id=111369260')) console.log('  счётчик Метрики 111369260 на месте');
else fail('счётчик Метрики не найден на главной');
if (home.includes('mc.yandex.ru/watch/111369260')) console.log('  noscript-пиксель на месте');
else warn('noscript-пиксель Метрики не найден');
if (home.includes('googletagmanager.com/gtag/js?id=G-WE8E8VWCS7')) console.log('  Google Analytics G-WE8E8VWCS7 на месте');
else fail('Google Analytics не найден на главной');

// 7. SEO-обвязка
const sitemap = await (await fetch(BASE + '/sitemap.xml')).text();
const urls = (sitemap.match(/<loc>/g) || []).length;
console.log(`  sitemap.xml: ${urls} адресов`);
if (urls < 40) warn('в карте сайта меньше сорока адресов, проверить генерацию');

const robots = await (await fetch(BASE + '/robots.txt')).text();
if (robots.includes('Sitemap:')) console.log('  robots.txt ссылается на карту сайта');
else fail('robots.txt без ссылки на sitemap');

let noCanonical = 0;
for (const [path, html] of pages) {
  if (!/rel="canonical"/.test(html)) { noCanonical += 1; warn(`${path}: нет канонического адреса`); }
}
if (!noCanonical) console.log('  канонические адреса проставлены на всех проверенных страницах');

const ld = (allHtml.match(/application\/ld\+json/g) || []).length;
console.log(`  блоков микроразметки на проверенных страницах: ${ld}`);

// 8. свежесть
console.log('\n5. Свежесть данных');
// В демо-режиме на сайте обязана висеть плашка, в боевом её быть не должно
const isDemo = home.includes('Демонстрационные данные');
if (isDemo) {
  console.log('  режим демо: плашка на месте, цены выдавать за реальные нельзя');
} else {
  console.log('  режим боевой: плашки нет, значит все показанные цены обязаны быть проверенными');
  const demoWords = [...pages.values()].filter((h) => /демонстрационн/i.test(strip(h))).length;
  if (demoWords) fail(`в боевом режиме на ${demoWords} страницах осталось слово «демонстрационные»`);
  else console.log('  упоминаний демо-данных в текстах не осталось');
}
if ((pages.get('/ru/catalog') || '').includes('Проверено')) console.log('  в русском каталоге есть колонка с датой проверки');
else fail('в русском каталоге нет колонки с датой проверки');
if ((pages.get('/catalog') || '').includes('Verified')) console.log('  в английском каталоге есть колонка с датой проверки');
else fail('в английском каталоге нет колонки Verified');

// 9. битые внутренние ссылки
// Проверка появилась после удаления раздела «Как мы зарабатываем»: страницу снесли,
// а ссылки на неё могли остаться в футере, в калькуляторе и в текстах материалов
console.log('\n6. Внутренние ссылки');
const internal = new Set();
for (const html of pages.values()) {
  for (const [, href] of html.matchAll(/href="(\/[^"#?]*)"/g)) {
    if (!href.startsWith('/_next/') && !/\.(css|js|png|svg|ico|xml|txt|webmanifest)$/.test(href)) {
      internal.add(href === '' ? '/' : href);
    }
  }
}
let dead = 0;
for (const href of internal) {
  const res = await fetch(BASE + href, { redirect: 'follow' });
  if (!res.ok) { dead += 1; fail(`битая внутренняя ссылка ${href}: ${res.status}`); }
}
if (!dead) console.log(`  проверено адресов: ${internal.size}, все отвечают`);

console.log(`\nИтог: ошибок ${errors}, предупреждений ${warnings}`);
process.exit(errors ? 1 : 0);
